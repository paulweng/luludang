# -*- coding:utf-8 -*-
import _thread
import json
import sys
import threading

from coindata.model_def import Ticker
import websocket

# websocket地址
WS_SERVER = 'wss://api.fcoin.com/v2/ws'


class CoinData:

    """
    symbols : [] 交易对列表
    ticker_size : 存储的ticker数据长度
    hander : ticker推送回调函数
    """
    def __init__(self, symbols, ticker_size, handler):
        self.__symbols = symbols
        self.__handler = handler
        self.__ticker_size = ticker_size
        self.__ticker_dict = {}

    def __on_message(self, ws, message):
        # print(type(message)
        msg = json.loads(message)

        if 'type' in msg:
            if msg['type'] == 'hello':
                print('welcome：', message)
            elif msg['type'].startswith('ticker'):
                # print('ticker数据：', message)

                symbol = msg['type'][7:]
                last_price = msg['ticker'][0]
                last_volume = msg['ticker'][1]
                bid_price = msg['ticker'][2]
                bid_volume = msg['ticker'][3]
                ask_price = msg['ticker'][4]
                ask_volume = msg['ticker'][5]

                ticker = Ticker(symbol, last_price, last_volume, bid_price, bid_volume, ask_price, ask_volume)

                if ticker.get_symbol() in self.__ticker_dict:

                    ticker_list = self.__ticker_dict[ticker.get_symbol()]

                    if len(ticker_list) < self.__ticker_size:
                        ticker_list.append(ticker)
                    else:
                        del ticker_list[0]
                        ticker_list.append(ticker)
                else:
                    self.__ticker_dict[ticker.get_symbol()] = [ticker]

                self.__handler(ticker)

    def __on_error(self, ws, error):
        print(error)

    def __on_close(self, ws):
        print("### closed ###")

    def __on_open(self, ws):
        print("### opened ###")

        for symbol in self.__symbols:
            print('{"cmd":"sub","args":["ticker.' + symbol + '"],"id":"zjf"}')
            ws.send('{"cmd":"sub","args":["ticker.' + symbol + '"],"id":"zjf"}')

    def __run(self):
        self.__ws.run_forever()

    def connect(self):
        self.__ws = websocket.WebSocketApp(WS_SERVER,
                                    on_message=self.__on_message,
                                    on_error=self.__on_error,
                                    on_close=self.__on_close)
        self.__ws.on_open = self.__on_open
        try:
            _thread.start_new_thread(self.__run, ())
        except:
            print("Unexpected error:", sys.exc_info()[0])


    # 获取最新ticker
    def get_last_ticker(self, symbol):
        # print(self.__ticker_dict)
        if symbol in self.__ticker_dict:
            ticker_list = self.__ticker_dict[symbol]
            return ticker_list[len(ticker_list) - 1]

    # 获取所有ticker
    def get_all_tickers(self, symbol):
        if symbol in self.__ticker_dict:
            return self.__ticker_dict[symbol]
        else:
            return []
